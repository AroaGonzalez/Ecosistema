package ud.prog3.pr00.simulador;

public interface Evolucionable {
	
	public void evoluciona(int dias);

}
